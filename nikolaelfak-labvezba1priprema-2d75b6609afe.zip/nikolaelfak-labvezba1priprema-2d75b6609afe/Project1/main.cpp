#include "Proba.h"

void main() {

	Proba a;
	
}