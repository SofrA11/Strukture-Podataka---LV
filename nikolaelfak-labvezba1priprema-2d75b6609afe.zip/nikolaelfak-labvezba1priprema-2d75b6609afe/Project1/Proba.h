#pragma once
#include <iostream>
using namespace std;
class Proba
{

	void print() {
		cout << "cao";
	}
};

