#include "Stack.h"

void main()
{
	
}