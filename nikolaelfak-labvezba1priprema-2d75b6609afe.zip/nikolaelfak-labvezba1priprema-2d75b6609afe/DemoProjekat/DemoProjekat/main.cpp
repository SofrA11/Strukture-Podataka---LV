#include <iostream>
using namespace std;
void main()
{
	cout << "test";
}