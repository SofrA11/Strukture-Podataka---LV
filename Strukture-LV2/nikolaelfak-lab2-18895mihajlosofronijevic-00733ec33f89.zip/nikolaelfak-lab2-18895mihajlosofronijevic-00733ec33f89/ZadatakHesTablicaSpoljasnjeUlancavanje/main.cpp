#pragma once
#include"ChainedHashTable.h"

void main()
{
	ChainedHashTable tablica(64);
	//TODO: dodati testiranje tablice prema zahtevu zadatka
}