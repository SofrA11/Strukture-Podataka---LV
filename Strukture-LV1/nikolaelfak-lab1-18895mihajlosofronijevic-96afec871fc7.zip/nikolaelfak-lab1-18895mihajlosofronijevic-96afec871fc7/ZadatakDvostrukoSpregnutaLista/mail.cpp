#include"DList.h"

void main()
{
	DList *list = new DList();
	list->addToHead(6);
	list->addToHead(3);
	list->addToHead(2);
	list->addToHead(7);
	list->addToHead(2);
	list->addToHead(2);
	list->addToHead(1);
	list->addToHead(9);
	list->addToHead(9);
	list->addToHead(4);

	list->printAll();
	list->deleteAllOccurrences(2);
	list->printAll();
	list->deleteAllOccurrences(4);
	list->printAll();
	list->deleteAllOccurrences(9);
	list->printAll();

	delete list;
}